/*
 * Copyright (C) 2010-2013, Martin Goellnitz
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA, 02110-1301, USA
 */
package jfs.sync.cifs;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.util.Map;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;
import jfs.conf.JFSConfig;
import jfs.sync.encryption.FileInfo;
import jfs.sync.encryption.StorageAccess;
import jfs.sync.meta.AbstractMetaStorageAccess;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CifsStorageAccess extends AbstractMetaStorageAccess implements StorageAccess {

    private static Log log = LogFactory.getLog(CifsStorageAccess.class);

    private NtlmPasswordAuthentication auth;


    public CifsStorageAccess(String cipher) {
        super(cipher);
        String[] credentials = JFSConfig.getInstance().getServerPassPhrase().split("\\|");
        auth = new NtlmPasswordAuthentication(null, credentials[0], credentials[1]);
    } // FtpStorageAccess()


    protected SmbFile getSmbFile(String rootPath, String relativePath) {
        String path = getFileName(relativePath);
        SmbFile smbFile = null;
        try {
            smbFile = new SmbFile(rootPath+path, auth);
        } catch (MalformedURLException e) {
            log.error("getSmbFile()", e);
        } // try/catch
        return smbFile;
    } // getFile()


    /**
     * create non existent files
     * 
     * @param file
     * @param pathAndName
     * @return
     */
    private FileInfo createFileInfo(SmbFile file, String[] pathAndName) {
        FileInfo result = new FileInfo();

        result.setPath(pathAndName[0]);
        result.setName(pathAndName[1]);
        result.setCanRead(true);
        result.setCanWrite(true);
        try {
            result.setDirectory(file.isDirectory());
            result.setExists(file.exists());
            result.setModificationDate(file.lastModified());
            result.setSize(file.length());
        } catch (SmbException e) {
            log.error("createFileInfo()", e);
        } // try/catch

        if (log.isDebugEnabled()) {
            log.debug("createFileInfo("+pathAndName[0]+"/"+pathAndName[1]+") "+result);
        } // if

        return result;
    } // createFileInfo()


    @Override
    public FileInfo getFileInfo(String rootPath, String relativePath) {
        String[] pathAndName = getPathAndName(relativePath);
        FileInfo result = getParentListing(rootPath, pathAndName).get(pathAndName[1]);
        if (result==null) {
            result = createFileInfo(getSmbFile(rootPath, relativePath), pathAndName);
        } // if
        return result;
    } // getFileInfo()


    @Override
    public boolean createDirectory(String rootPath, String relativePath) {
        SmbFile file = getSmbFile(rootPath, relativePath);
        boolean success = false;
        try {
            file.mkdir();
            success = file.exists();
        } catch (SmbException e) {
            log.error("createDirectory()", e);
        } // try/catch
        if (success) {
            String[] pathAndName = getPathAndName(relativePath);
            Map<String, FileInfo> listing = getParentListing(rootPath, pathAndName);
            if (log.isDebugEnabled()) {
                log.debug("createDirectory() "+relativePath);
                log.debug("createDirectory() listing="+listing);
            } // if
            FileInfo info = createFileInfo(file, pathAndName);
            listing.put(pathAndName[1], info);
            if (log.isDebugEnabled()) {
                log.debug("createDirectory() listing="+listing);
            } // if
            if (log.isInfoEnabled()) {
                log.info("createDirectory() flushing "+pathAndName[0]+"/"+pathAndName[1]);
            } // if
            flushMetaData(rootPath, pathAndName, listing);
        } // if
        if (log.isDebugEnabled()) {
            log.debug("createDirectory() "+success);
        } // if
        return success;
    } // createDirectory()


    @Override
    public boolean setLastModified(String rootPath, String relativePath, long modificationDate) {
        boolean success = getFile(rootPath, relativePath).setLastModified(modificationDate);
        if (success) {
            String[] pathAndName = getPathAndName(relativePath);
            Map<String, FileInfo> listing = getParentListing(rootPath, pathAndName);
            FileInfo info = listing.get(pathAndName[1]);
            if (log.isInfoEnabled()) {
                log.info("setLastModified() flushing "+pathAndName[0]+"/"+pathAndName[1]);
            } // if
            info.setModificationDate(modificationDate);
            flushMetaData(rootPath, pathAndName, listing);
        } // if
        return success;
    } // setLastModified()


    @Override
    public boolean setReadOnly(String rootPath, String relativePath) {
        if (log.isInfoEnabled()) {
            log.info("setReadOnly() not flushing "+relativePath);
        } // if
        return getFile(rootPath, relativePath).setReadOnly();
    } // setReadOnly()


    @Override
    public boolean delete(String rootPath, String relativePath) {
        String[] pathAndName = getPathAndName(relativePath);
        Map<String, FileInfo> listing = getParentListing(rootPath, pathAndName);
        if (log.isDebugEnabled()) {
            log.debug("delete() "+relativePath);
            log.debug("delete() listing="+listing);
        } // if
          // remove named item
        SmbFile file = getSmbFile(rootPath, relativePath);
        FileInfo info = listing.get(pathAndName[1]);
        if (info!=null) {
            listing.remove(pathAndName[1]);
            if (log.isInfoEnabled()) {
                log.info("delete() flushing "+pathAndName[0]+"/"+pathAndName[1]);
            } // if
            flushMetaData(rootPath, pathAndName, listing);
            if (log.isInfoEnabled()) {
                log.info("delete() listing="+listing);
            } // if
            if (info.isDirectory()) {
                String metaDataPath = getMetaDataPath(relativePath);
                SmbFile metaDataFile = getSmbFile(rootPath, metaDataPath);
                try {
                    if (metaDataFile.exists()) {
                        metaDataFile.delete();
                    } // if
                } catch (SmbException e) {
                    log.error("delete() - deleting meta data file ", e);
                } // try/catch
            } // if
            try {
                file.delete();
            } catch (SmbException e) {
                log.error("delete()", e);
            } // try/catch
        } // if

        boolean success = false;
        try {
            success = !file.exists();
        } catch (SmbException e) {
            log.error("delete()", e);
        } // try/catch
        return success;
    } // delete()


    @Override
    public InputStream getInputStream(String rootPath, String relativePath) throws IOException {
        SmbFile file = getSmbFile(rootPath, relativePath);
        if (log.isDebugEnabled()) {
            log.debug("getInputStream() getting input stream for "+file.getPath());
        } // if
        return file.getInputStream();
    } // getInputStream()


    @Override
    protected OutputStream getOutputStream(String rootPath, String relativePath, boolean forPayload) throws IOException {
        SmbFile file = getSmbFile(rootPath, relativePath);
        String[] pathAndName = getPathAndName(relativePath);
        if (forPayload&&( !file.exists())) {
            FileInfo info = createFileInfo(file, pathAndName);
            Map<String, FileInfo> listing = getParentListing(rootPath, pathAndName);
            listing.put(info.getName(), info);
            if (log.isInfoEnabled()) {
                log.info("getOutputStream() flushing "+pathAndName[0]+"/"+pathAndName[1]);
            } // if
            flushMetaData(rootPath, pathAndName, listing);
            if (log.isDebugEnabled()) {
                log.debug("getOutputStream() getting output stream for "+file.getPath()+" "+info);
            } // if
        } // if
        if (log.isDebugEnabled()) {
            log.debug("getOutputStream() getting output stream for "+file.getPath());
        } // if
        OutputStream result = file.getOutputStream();
        FileInfo info = createFileInfo(file, pathAndName);
        if (log.isDebugEnabled()) {
            log.debug("getOutputStream() have output stream for "+file.getPath()+" "+info+" "+result);
        } // if
        return result;
    } // getOutputStream()

} // FtpStorageAccess
