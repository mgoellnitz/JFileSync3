/*
 * Copyright (C) 2010-2013, Martin Goellnitz
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA, 02110-1301, USA
 */
package jfs.sync.dropbox;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

import jfs.sync.encryption.FileInfo;
import jfs.sync.encryption.StorageAccess;
import jfs.sync.meta.AbstractMetaStorageAccess;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.dropbox.client2.DropboxAPI;
import com.dropbox.client2.DropboxAPI.Entry;
import com.dropbox.client2.exception.DropboxException;
import com.dropbox.client2.session.AppKeyPair;
import com.dropbox.client2.session.Session;
import com.dropbox.client2.session.Session.AccessType;
import com.dropbox.client2.session.WebAuthSession;
import com.dropbox.client2.session.WebAuthSession.WebAuthInfo;

public class DropboxStorageAccess extends AbstractMetaStorageAccess implements StorageAccess {

    private static final String APP_KEY = "y6jxuv9dlxpji7i";

    private static final String APP_SECRET = "fdbhzer071glw48";

    private static long outputStreams;

    private static long inputStreams;

    private static Log log = LogFactory.getLog(DropboxStorageAccess.class);

    private DropboxAPI<Session> api;


    public DropboxStorageAccess(String cipher) {
        super(cipher);
        AppKeyPair appKeys = new AppKeyPair(APP_KEY, APP_SECRET);
        AccessType accessType = AccessType.APP_FOLDER;

        WebAuthSession session = new WebAuthSession(appKeys, accessType);

        try {
            WebAuthInfo webAuthInfo = session.getAuthInfo();
            System.out.println(webAuthInfo.url);

            Thread.sleep(10000);

            String uid = session.retrieveWebAccessToken(webAuthInfo.requestTokenPair);
            System.out.println("here we go: "+uid);

            api = new DropboxAPI<Session>(session);
        } catch (InterruptedException ie) {
            // who cares
        } catch (DropboxException de) {
            log.fatal("()", de);
        } // try/catch

        // Entry entry = api.createFolder("nase");

        api.getSession().unlink();
    }


    @Override
    public String getSeparator() {
        return File.separator;
    }


    /**
     * create non existent files
     * 
     * @param file
     * @param pathAndName
     * @return
     */
    private FileInfo createFileInfo(Entry entry, String[] pathAndName) {
        FileInfo result = new FileInfo();

        result.setCanRead(true);
        result.setCanWrite(true);
        result.setDirectory(entry==null ? false : entry.isDir);
        result.setExists(entry!=null);
        result.setModificationDate(Long.parseLong(entry.modified));
        result.setName(pathAndName[1]);
        result.setPath(pathAndName[0]);
        result.setSize(entry.bytes);

        if (log.isDebugEnabled()) {
            log.debug("getFileInfo("+pathAndName[0]+"/"+pathAndName[1]+") "+result);
        } // if

        return result;
    } // createFileInfo()


    protected Entry getEntry(String rootPath, String relativePath) {
        String path = getFileName(relativePath);
        Entry result = null;
        try {
            result = api.metadata(path, 0, "", false, "");
        } catch (DropboxException de) {
            log.error("getFile() "+relativePath+" / "+path, de);
        } // try/catch
        return result;
    } // getEntry()


    public FileInfo getFileInfo(String rootPath, String relativePath) {
        String[] pathAndName = getPathAndName(relativePath);
        FileInfo result = getParentListing(rootPath, pathAndName).get(pathAndName[1]);
        if (result==null) {
            Entry entry;
            try {
                entry = api.metadata(getFileName(relativePath), 0, "", false, "");
                result = createFileInfo(entry, pathAndName);
            } catch (DropboxException de) {
                log.error("getFileInfo() "+relativePath, de);
            } // try/catch
        } // if
        return result;
    } // getFileInfo()


    public boolean createDirectory(String rootPath, String relativePath) {
        boolean success = false;
        Entry entry = null;
        try {
            entry = api.createFolder(getFileName(relativePath));
            success = true;
        } catch (DropboxException de) {
            log.error("createDirectory() "+relativePath, de);
        } // try/catch
        if (success) {
            String[] pathAndName = getPathAndName(relativePath);
            Map<String, FileInfo> listing = getParentListing(rootPath, pathAndName);
            if (log.isDebugEnabled()) {
                log.debug("createDirectory() "+relativePath);
                log.debug("createDirectory() listing="+listing);
            } // if
            FileInfo info = createFileInfo(entry, pathAndName);
            listing.put(pathAndName[1], info);
            if (log.isDebugEnabled()) {
                log.debug("createDirectory() listing="+listing);
            } // if
            if (log.isInfoEnabled()) {
                log.info("createDirectory() flushing "+pathAndName[0]+"/"+pathAndName[1]);
            } // if
            flushMetaData(rootPath, pathAndName, listing);
        } // if
        if (log.isDebugEnabled()) {
            log.debug("createDirectory() "+success);
        } // if
        return success;
    } // createDirectory()


    @Override
    public boolean setLastModified(String rootPath, String relativePath, long modificationDate) {
        String[] pathAndName = getPathAndName(relativePath);
        Map<String, FileInfo> listing = getParentListing(rootPath, pathAndName);
        FileInfo info = listing.get(pathAndName[1]);
        if (log.isInfoEnabled()) {
            log.info("setLastModified() flushing "+pathAndName[0]+"/"+pathAndName[1]);
        } // if
        info.setModificationDate(modificationDate);
        flushMetaData(rootPath, pathAndName, listing);
        return true;
    } // setLastModified()


    @Override
    public boolean setReadOnly(String rootPath, String relativePath) {
        return false;
    } // setReadOnly()


    @Override
    public boolean delete(String rootPath, String relativePath) {
        String[] pathAndName = getPathAndName(relativePath);
        Map<String, FileInfo> listing = getParentListing(rootPath, pathAndName);
        if (log.isDebugEnabled()) {
            log.debug("delete() "+relativePath);
            log.debug("delete() listing="+listing);
        } // if
          // remove named item
        if (listing.containsKey(pathAndName[1])) {
            listing.remove(pathAndName[1]);
            if (log.isInfoEnabled()) {
                log.info("delete() flushing "+pathAndName[0]+"/"+pathAndName[1]);
            } // if
            flushMetaData(rootPath, pathAndName, listing);
            if (log.isInfoEnabled()) {
                log.info("delete() listing="+listing);
            } // if
            if (getEntry(rootPath, relativePath).isDir) {
                String metaDataPath = getMetaDataPath(relativePath);
                try {
                    api.delete(getFileName(metaDataPath));
                } catch (DropboxException de) {
                    log.error("delete() "+metaDataPath, de);
                } // try/catch
            } // if
            try {
                api.delete(getFileName(relativePath));
            } catch (DropboxException de) {
                log.error("delete() "+relativePath, de);
            } // try/catch
        } // if
        return getEntry(rootPath, relativePath).isDeleted;
    } // delete()


    @Override
    public InputStream getInputStream(String rootPath, String relativePath) throws IOException {
        try {
            String fileName = getFileName(relativePath);
            InputStream result = api.getFileStream(fileName, "");
            if (log.isDebugEnabled()) {
                log.debug("getInputStream() getting input stream for "+fileName);
            } // if
            inputStreams++ ;
            if (log.isDebugEnabled()) {
                log.debug("getInputStream("+relativePath+") inputStreams="+inputStreams);
            } // if
            return result;
        } catch (DropboxException de) {
            log.error("getInputStream() "+relativePath, de);
            throw new IOException(de);
        } // try/catch
    } // getInputStream()


    @Override
    protected OutputStream getOutputStream(String rootPath, String relativePath, boolean forPayload) throws IOException {
        Entry file = getEntry(rootPath, relativePath);
        String[] pathAndName = getPathAndName(relativePath);
        if (forPayload&&(file==null)) {
            FileInfo info = createFileInfo(file, pathAndName);
            Map<String, FileInfo> listing = getParentListing(rootPath, pathAndName);
            listing.put(info.getName(), info);
            if (log.isInfoEnabled()) {
                log.info("getOutputStream() flushing "+pathAndName[0]+"/"+pathAndName[1]);
            } // if
            flushMetaData(rootPath, pathAndName, listing);
            if (log.isDebugEnabled()) {
                log.debug("getOutputStream() getting output stream for "+relativePath+" "+info);
            } // if
        } // if
        if (log.isDebugEnabled()) {
            log.debug("getOutputStream() getting output stream for "+file.path);
        } // if
        outputStreams++ ;
        if (log.isInfoEnabled()) {
            log.info("getOutputStream("+relativePath+") outputStreams="+outputStreams);
        } // if
        OutputStream result = null; // TODO: implement
        FileInfo info = createFileInfo(file, pathAndName);
        if (log.isDebugEnabled()) {
            log.debug("getOutputStream() have output stream for "+file.path+" "+info+" "+result);
        } // if
        return result;
    } // getOutputStream()


    @Override
    public OutputStream getOutputStream(String rootPath, String relativePath) throws IOException {
        return getOutputStream(rootPath, relativePath, true);
    } // getOutputStream()


    @Override
    public void flush(String rootPath, FileInfo info) {
        String[] pathAndName = new String[2];
        pathAndName[0] = info.getPath();
        pathAndName[1] = info.getName();
        Map<String, FileInfo> listing = getParentListing(rootPath, pathAndName);
        if (listing.containsKey(info.getName())) {
            listing.remove(info.getName());
        } // if
        listing.put(info.getName(), info);
        if (log.isInfoEnabled()) {
            log.info("flush() flushing "+pathAndName[0]+"/"+pathAndName[1]);
        } // if
        flushMetaData(rootPath, pathAndName, listing);
    } // flush()

} // DropboxStorageAccess
