package jfs.sync.dropbox;

import com.dropbox.client2.DropboxAPI;
import com.dropbox.client2.session.AppKeyPair;
import com.dropbox.client2.session.Session;
import com.dropbox.client2.session.Session.AccessType;
import com.dropbox.client2.session.WebAuthSession;
import com.dropbox.client2.session.WebAuthSession.WebAuthInfo;

public class Test {
    
    private static final String APP_KEY = "y6jxuv9dlxpji7i";

    private static final String APP_SECRET = "fdbhzer071glw48";


    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        AppKeyPair appKeys = new AppKeyPair(APP_KEY, APP_SECRET);
        AccessType accessType = AccessType.APP_FOLDER;

        WebAuthSession session = new WebAuthSession(appKeys, accessType);
        
        WebAuthInfo webAuthInfo = session.getAuthInfo();
        System.out.println(webAuthInfo.url);
        
        Thread.sleep(10000);
        
        String uid = session.retrieveWebAccessToken(webAuthInfo.requestTokenPair);
        System.out.println("here we go: "+uid);
        
        DropboxAPI<Session> api = new DropboxAPI<Session>(session);
        
        // Entry entry = api.createFolder("nase");
        
        api.getSession().unlink();
    }

}
